from tkinter import*
from tkinter import ttk
import pymysql

class Student:
    def __init__(self,root):
        self.root=root
        self.root.title("AlgoScale User Management System")
        self.root.geometry("1350x700+0+0")

        title=Label(self.root,text="User Management System",bd=10,relief=GROOVE,font=("times new roman",40,"bold"),bg="Blue",fg="yellow")
        title.pack(side=TOP,fill=X)
        ##############  All Variables#################
        self.Username=StringVar()
        self.Password=StringVar()


        Manage_Frame=Frame(self.root,bd=4,relief=RIDGE,bg="#1099f9")
        Manage_Frame.place(x=20,y=100,width=450,height=560)

        mtitle=Label(Manage_Frame,text="Manage Users",bg="#1099f9",fg="White",font=("times new roman",20,"bold"))
        mtitle.grid(row=0,columnspan=2,pady=20)

        lbl_username=Label(Manage_Frame,text="User Name",bg="#1099f9",fg="White",font=("times new roman",20,"bold"))
        lbl_username.grid(row=1,column=0,pady=5,padx=5,sticky="w")

        txt_username=Entry(Manage_Frame,textvariable=self.Username,font=("times new roman",20,"bold"))
        txt_username.grid(row=1,column=1,pady=1,padx=5,sticky="w")

        lbl_password=Label(Manage_Frame,text="Password",bg="#1099f9",fg="White",font=("times new roman",20,"bold"))
        lbl_password.grid(row=2,column=0,pady=5,padx=5,sticky="w")
        txt_password=Entry(Manage_Frame,textvariable=self.Password,font=("times new roman",20,"bold"))
        txt_password.grid(row=2,column=1,pady=1,padx=5,sticky="w")

###################Button Area################
        btn_Frame=Frame(Manage_Frame,bd=4,relief=RIDGE,bg="#1099f9")
        btn_Frame.place(x=10,y=280,width=410)

        Addbtn=Button(btn_Frame,text="Add",command=self.add_user,width=10).grid(row=0,column=0,padx=10,pady=10)
        Updatebtn=Button(btn_Frame,command=self.updateUser,text="Update",width=10).grid(row=0,column=1,padx=10,pady=10)
        Deletebtn=Button(btn_Frame,command=self.deleteUser,text="Delete",width=10).grid(row=0,column=2,padx=10,pady=10)
        Clearbtn=Button(btn_Frame,text="Clear",command=self.clear,width=10).grid(row=0,column=3,padx=10,pady=10)

######################
        Detail_Frame=Frame(self.root,bd=4,relief=RIDGE,bg="#1099f9")
        Detail_Frame.place(x=500,y=100,width=800,height=560)

        lbl_Search=Label(Detail_Frame,text="Search By",bg="#1099f9",fg="White",font=("times new roman",20,"bold"))
        lbl_Search.grid(row=0,column=0,pady=5,padx=5,sticky="w")

        combo_search=ttk.Combobox(Detail_Frame,font=("times new roman",13,"bold"),state='readonly')
        combo_search['values']=("Username")
        combo_search.grid(row=0,column=1,padx=20,pady=10)

        txt_Search=Entry(Detail_Frame,font=("times new roman",20,"bold"),width=10)
        txt_Search.grid(row=0,column=2,pady=10,padx=20,sticky="w")
        searchbtn=Button(Detail_Frame,text="Search",width=10).grid(row=0,column=3,padx=20)
        showallbtn=Button(Detail_Frame,text="Logout",command=self.logout,width=10).grid(row=0,column=4)

        #################### Show All Record ###############
        Table_Frame=Frame(Detail_Frame,bd=4,relief=RIDGE,bg="#1099f9")
        Table_Frame.place(x=50,y=100,width=700,height=300)

        self.User_table=ttk.Treeview(Table_Frame,columns=("id","username","password"))
        self.User_table.heading("id",text="ID")
        self.User_table.heading("username",text="User Name")
        self.User_table.heading("password",text="Password")
        self.User_table['show']='headings'
        self.User_table.pack()
        self.User_table.bind("<ButtonRelease-1>",self.get_cursor)
        self.get_user()

    def add_user(self):
        con=pymysql.connect(host="localhost",user="root",password="",database="user")
        cur=con.cursor()
        cur.execute("insert into employee values(%s,%s,%s)",('',self.Username.get(),self.Password.get()))
        con.commit()
        self.get_user()
        self.clear()
        con.close()
    def get_user(self):
        con=pymysql.connect(host="localhost",user="root",password="",database="user")
        cur=con.cursor()
        cur.execute("select * from employee")
        rows=cur.fetchall()
        if len(rows)!=0:
            self.User_table.delete(*self.User_table.get_children())
            for row in rows:
                self.User_table.insert('',END,values=row)
            con.commit()
        con.close()
    def clear(self):
        self.Username.set("")
        self.Password.set("")
    def get_cursor(self,ev):
        cursor_row=self.User_table.focus()
        contents=self.User_table.item(cursor_row)
        row11=contents['values']
       # print(row11)
        self.Username.set(row11[1])
        self.Password.set(row11[2])

    def updateUser(self):
        con=pymysql.connect(host="localhost",user="root",password="",database="user")
        cur=con.cursor()
        cur.execute("update employee set  username=%s,password=%s where username=%s",(self.Username.get(),self.Password.get(),self.Username.get()))
        con.commit()
        self.get_user()
        self.clear()
        con.close()
    def deleteUser(self):
        con=pymysql.connect(host="localhost",user="root",password="",database="user")
        cur=con.cursor()
        cur.execute("delete from employee where username=%s",self.Username.get())
        con.commit()
        self.get_user()
        self.clear()
        con.close()
    def logout(self):
         self.root.destroy()
         import login




root=Tk()
ob=Student(root)
root.mainloop()

