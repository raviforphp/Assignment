from tkinter import*
from PIL import ImageTk
from tkinter import messagebox
import pymysql
class Login:
    def __init__(self,root):
        self.root=root
        self.root.title("Login System")
        self.root.geometry("1199x660+100+50")
        #=====bg image===========#
        self.bg=ImageTk.PhotoImage(file="images/Penguins.jpg")
        self.bg_image=Label(self.root,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)
        #============Login Frame==============#
        Frame_login=Frame(self.root,bg="white")
        Frame_login.place(x=350,y=150,height=350,width=500)

        title=Label(Frame_login,text="Login Here", font=("Impact",30,"bold"), fg="#338aff").place(x=150,y=30)
        desc=Label(Frame_login,text="Algoscale User Management", font=("Goudy",15), fg="#338eef").place(x=110,y=90)

        lbl_user=Label(Frame_login,text="UserName", font=("Goudy",15), fg="#000000").place(x=50,y=120)
        self.txt_user=Entry(Frame_login,font=("times new roman",15),bg="lightgray")
        self.txt_user.place(x=50,y=150,width=300)

        lbl_pass=Label(Frame_login,text="Password", font=("Goudy",15), fg="#000000").place(x=50,y=180)
        self.txt_pass=Entry(Frame_login,font=("times new roman",15),bg="lightgray")
        self.txt_pass.place(x=50,y=210,width=300)
        forget_btn=Button(Frame_login,text="Forget Password?",bg="#3346ff",fg="#ffffff").place(x=50,y=250,width=130)
        login_btn=Button(Frame_login,text="Login",command=self.login_function,bg="#3346ff",fg="#ffffff").place(x=210,y=250,width=130)

    def login_function(self):
        if self.txt_user.get()=="" or self.txt_pass.get()=="":
            messagebox.showerror("Error","Please Enter User Name and Password",parent=self.root)
        elif self.txt_user.get()!="Ravi" or self.txt_pass.get()!="12345":
            messagebox.showerror("Error","Invalid UserName/Password",parent=self.root)
        else:
            # messagebox.showinfo("Welcome","You are login")
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="user")
                cur=con.cursor()
                cur.execute("select * from employee where username=%s and password=%s",(self.txt_user.get(),self.txt_pass.get()))
                row=cur.fetchone()
                #print(row)
                if row==None:
                     messagebox.showerror("Error","Invalid Credential",parent=self.root)
                else:
                    messagebox.showinfo("Welcome","Welcome In Algoscale User Management",parent=self.root)
                    self.root.destroy()
                    import userManagement
                con.close()

            except EXCEPTION as es:
                messagebox.showerror("Error",f"Error due to {str(es)}",parent=self.root)




root=Tk()
obj=Login(root)
root.mainloop()
